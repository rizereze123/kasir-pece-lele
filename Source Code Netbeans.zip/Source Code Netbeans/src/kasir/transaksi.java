/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package kasir;

import java.awt.event.KeyEvent;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;
import java.util.Date;

/**
 *
 * @author dhimaz
 */

public class transaksi extends javax.swing.JFrame {
Connection koneksi;
PreparedStatement pst, pst2, pstmt, pstmt2, pstmt3;
ResultSet rst, rst2, rs, rs2;
int istok, istok2, iharga, ijumlah, kstok, tstok;
String harga, barang, dbarang, KD, jam, tanggal,ssub;

int selectedJumlah;
String selectedId, selectedKB;
    /**
     * Creates new form transaksi
     */
    public transaksi() {
        initComponents();
    koneksi=database.koneksiDB();
        delay();
        detail();    
        autonumber();
        sum();
    }
    
    private void simpan(){
        String tgl=Date.getText();
        String jam=Time.getText();
      try {
            String sql="insert into transaksi (Kode_Transaksi,Kode_Detail,Tanggal,Jam,Total) value (?,?,?,?,?)";
            pst=koneksi.prepareStatement(sql);
            pst.setString(1, KodeTransaksi.getText());
            pst.setString(2, KD);
            pst.setString(3, tgl);
            pst.setString(4, jam);
            pst.setString(5, TotalHarga.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Data Tersimpan");
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
            }
    }
    
    private void total(){
    int total, bayar, kembali;
        total= Integer.parseInt(InputCash.getText());
        bayar= Integer.parseInt(TotalHarga.getText());
        kembali = total-bayar;
        ssub=String.valueOf(kembali);
        UangKembalian.setText(ssub);
    }
    
    public void clsr(){
    InputQty.setText("");
    InputDiscount.setText("");
    }
    
    public void cari(){
    try {
        String sql="select * from barang where Nama_Barang LIKE '%"+InputProductName.getText()+"%'";
        pst=koneksi.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        rst=pst.executeQuery();
        TabelInputProductName.setModel(DbUtils.resultSetToTableModel(rst));
       } catch (Exception e){ 
           JOptionPane.showMessageDialog(null, e);
       } 
    }
    
    public void kurangi_stok(){
    int qty;
    qty=Integer.parseInt(InputQty.getText());
    if(qty>istok){
        JOptionPane.showMessageDialog(null, "The Products You Buy Are In Less Stock!!");
    }
    else{
        kstok=istok-qty;
        try {
        String diskon;
            if (InputDiscount.getText().equals("")) {
                diskon="0";
            }
            else {
                diskon=InputDiscount.getText();
            }
        String Kode_detail=KodeTransaksi.getText();
        KD="D"+Kode_detail;
            String sql="insert into detail_barang (Kode_Detail,Kode_Barang,Harga,Jumlah,Discount,Subtotal) value (?,?,?,?,?,?)";
            String update="update barang set Stok='"+kstok+"' where Kode_Barang='"+barang+"'";
            pst=koneksi.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            pst2=koneksi.prepareStatement(update, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            pst.setString(1, KD);
            pst.setString(2, barang);
            pst.setString(3, harga);
            pst.setString(4, InputQty.getText());
            pst.setString(5, diskon);
            pst.setString(6, ssub);
            pst.execute();
            pst2.execute();
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
            }
        detail();
        sum();
        cari();
        clsr();
    }
    }
    
    private void subtotal(){
    int diskon, jumlah, sub;
            if (InputDiscount.getText().equals("")) {
                diskon=0;
            }
            else {
                diskon= Integer.parseInt(InputDiscount.getText());
            }
         jumlah= Integer.parseInt(InputQty.getText());
         sub=(jumlah*iharga)-diskon;
         ssub=String.valueOf(sub);     
    }
    
    public void tambah_stok(){
    tstok=ijumlah+istok2;
        try {
            String update="update barang set Stok='"+tstok+"' where Kode_Barang='"+barang+"'";
            pst2=koneksi.prepareStatement(update);
            pst2.execute();
        }catch (Exception e){JOptionPane.showMessageDialog(null, e);}
    }
    
    public void ambil_stock(){
        try {
        String sql="select * from barang where Kode_Barang='"+barang+"'";
        pst=koneksi.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        rst=pst.executeQuery();
            if (rst.next()) {    
            String stok=rst.getString(("Stok"));
            istok2= Integer.parseInt(stok);
            }
        }catch (Exception e) {JOptionPane.showMessageDialog(null, e);}
    }
    
    public void sum(){
        int totalBiaya = 0;
        int subtotal;
        DefaultTableModel dataModel = (DefaultTableModel) TabelKeranjang.getModel();
        int jumlah = TabelKeranjang.getRowCount();
        for (int i=0; i<jumlah; i++){
            subtotal = Integer.parseInt(dataModel.getValueAt(i, 6).toString());
            totalBiaya += subtotal;
        }
        TotalHarga.setText(String.valueOf(totalBiaya));
    }
    
    public void autonumber(){
    try{
        String sql = "SELECT MAX(RIGHT(Kode_Transaksi,3)) AS NO FROM transaksi";
        pst=koneksi.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        rst=pst.executeQuery();
        while (rst.next()) {
                if (rst.first() == false) {
                    KodeTransaksi.setText("TRX001");
                } else {
                    rst.last();
                    int auto_id = rst.getInt(1) + 1;
                    String no = String.valueOf(auto_id);
                    int NomorJual = no.length();
                    for (int j = 0; j < 3 - NomorJual; j++) {
                        no = "0" + no;
                    }
                    KodeTransaksi.setText("TRX" + no);
                }
            }
        rst.close();
        }catch (Exception e){JOptionPane.showMessageDialog(null, e);}
    }
    
    public void detail(){
    try {
        String Kode_detail=KodeTransaksi.getText();
        String KD="D"+Kode_detail;
        String sql="select * from detail_barang where Kode_Detail='"+KD+"'";
        pst=koneksi.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        rst=pst.executeQuery();
        TabelKeranjang.setModel(DbUtils.resultSetToTableModel(rst));
       } catch (Exception e){ JOptionPane.showMessageDialog(null, e);} 
    TabelKeranjang.getColumnModel().getColumn(0).setWidth(0);
    TabelKeranjang.getColumnModel().getColumn(0).setMinWidth(0);
    TabelKeranjang.getColumnModel().getColumn(0).setMaxWidth(0);
    }
    
    public void delay(){
    Thread clock=new Thread(){
        public void run(){
            for(;;){
                Calendar cal=Calendar.getInstance();
                SimpleDateFormat format=new SimpleDateFormat("HH:mm:ss");
                SimpleDateFormat format2=new SimpleDateFormat("yyyy-MM-dd");
                Time.setText(format.format(cal.getTime()));
                 Date.setText(format2.format(cal.getTime()));
                
            try { sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(transaksi.class.getName()).log(Level.SEVERE, null, ex);
            }
          }
        }
      };
    clock.start();
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TabelInputProductName = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabelKeranjang = new javax.swing.JTable();
        InputProductName = new javax.swing.JTextField();
        BtnSearch = new javax.swing.JToggleButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        LabelProductData = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        LabelCashier = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        LabelReport = new javax.swing.JLabel();
        LabelKaryawan = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        LabelLogout = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        KodeTransaksi = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        TotalHarga = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        InputCash = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        UangKembalian = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        InputQty = new javax.swing.JTextField();
        InputDiscount = new javax.swing.JTextField();
        BtnAdd = new javax.swing.JButton();
        BtnDelete = new javax.swing.JButton();
        BtnBayar = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        Time = new javax.swing.JTextField();
        Date = new javax.swing.JTextField();
        refresh = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Pecel Kasir - Cashier");

        TabelInputProductName.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelInputProductName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelInputProductNameMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelInputProductName);

        TabelKeranjang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelKeranjang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelKeranjangMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TabelKeranjang);

        BtnSearch.setText("Search");
        BtnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSearchActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(153, 0, 51));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(153, 0, 51));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        LabelProductData.setBackground(new java.awt.Color(255, 255, 255));
        LabelProductData.setFont(new java.awt.Font("Futura-Bold", 3, 14)); // NOI18N
        LabelProductData.setForeground(new java.awt.Color(255, 255, 255));
        LabelProductData.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasir/img/box1.png"))); // NOI18N
        LabelProductData.setText("Product Data");
        LabelProductData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LabelProductDataMouseClicked(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setForeground(new java.awt.Color(255, 255, 255));

        LabelCashier.setBackground(new java.awt.Color(153, 0, 51));
        LabelCashier.setFont(new java.awt.Font("Futura-Bold", 3, 14)); // NOI18N
        LabelCashier.setForeground(new java.awt.Color(153, 0, 51));
        LabelCashier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasir/img/cashier-machine.png"))); // NOI18N
        LabelCashier.setText("Cashier");
        LabelCashier.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LabelCashierMouseClicked(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(153, 0, 51));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        LabelReport.setBackground(new java.awt.Color(255, 255, 255));
        LabelReport.setFont(new java.awt.Font("Futura-Bold", 3, 14)); // NOI18N
        LabelReport.setForeground(new java.awt.Color(255, 255, 255));
        LabelReport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasir/img/stock-market-1.png"))); // NOI18N
        LabelReport.setText(" Report");
        LabelReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LabelReportMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(LabelReport)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(LabelReport)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(LabelCashier)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(LabelCashier)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        LabelKaryawan.setFont(new java.awt.Font("Futura-Bold", 3, 14)); // NOI18N
        LabelKaryawan.setForeground(new java.awt.Color(255, 255, 255));
        LabelKaryawan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasir/img/employees-1.png"))); // NOI18N
        LabelKaryawan.setText("Employees");
        LabelKaryawan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LabelKaryawanMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(LabelProductData))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(LabelKaryawan)))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(LabelProductData)
                .addGap(32, 32, 32)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(LabelKaryawan)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(153, 0, 51));

        LabelLogout.setFont(new java.awt.Font("Futura-Bold", 3, 14)); // NOI18N
        LabelLogout.setForeground(new java.awt.Color(255, 255, 255));
        LabelLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasir/img/logout.png"))); // NOI18N
        LabelLogout.setText(" Log Out");
        LabelLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LabelLogoutMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(LabelLogout)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addComponent(LabelLogout)
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 132, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jLabel7.setFont(new java.awt.Font("Futura Hv BT", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 0, 51));
        jLabel7.setText("Input Product Name");

        jLabel8.setFont(new java.awt.Font("Futura Hv BT", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(153, 0, 51));
        jLabel8.setText("Qty");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Futura-Bold", 3, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 0, 51));
        jLabel2.setText("Transaction Codes");

        KodeTransaksi.setFont(new java.awt.Font("Futura Hv BT", 3, 18)); // NOI18N
        KodeTransaksi.setCaretColor(new java.awt.Color(153, 0, 51));
        KodeTransaksi.setEnabled(false);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Futura-Bold", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 51));
        jLabel3.setText("Total ");

        TotalHarga.setFont(new java.awt.Font("Futura Hv BT", 3, 18)); // NOI18N
        TotalHarga.setCaretColor(new java.awt.Color(153, 0, 51));
        TotalHarga.setEnabled(false);
        TotalHarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalHargaActionPerformed(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Futura Hv BT", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 0, 51));
        jLabel5.setText("Cash");

        InputCash.setFont(new java.awt.Font("Futura Hv BT", 1, 14)); // NOI18N
        InputCash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputCashActionPerformed(evt);
            }
        });
        InputCash.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                InputCashKeyTyped(evt);
            }
        });

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Futura Hv BT", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 0, 51));
        jLabel6.setText("Change");

        UangKembalian.setFont(new java.awt.Font("Futura Hv BT", 0, 14)); // NOI18N
        UangKembalian.setEnabled(false);
        UangKembalian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UangKembalianActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Futura Hv BT", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 0, 51));
        jLabel4.setText("Discount");

        InputQty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputQtyActionPerformed(evt);
            }
        });
        InputQty.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                InputQtyPropertyChange(evt);
            }
        });
        InputQty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                InputQtyKeyTyped(evt);
            }
        });

        InputDiscount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputDiscountActionPerformed(evt);
            }
        });
        InputDiscount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                InputDiscountKeyTyped(evt);
            }
        });

        BtnAdd.setBackground(new java.awt.Color(0, 153, 51));
        BtnAdd.setForeground(new java.awt.Color(255, 255, 255));
        BtnAdd.setText("Add to Cart");
        BtnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAddActionPerformed(evt);
            }
        });

        BtnDelete.setBackground(new java.awt.Color(255, 102, 102));
        BtnDelete.setForeground(new java.awt.Color(255, 255, 255));
        BtnDelete.setText("Delete");
        BtnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnDeleteActionPerformed(evt);
            }
        });

        BtnBayar.setBackground(new java.awt.Color(102, 102, 255));
        BtnBayar.setFont(new java.awt.Font("Futura Hv BT", 0, 12)); // NOI18N
        BtnBayar.setForeground(new java.awt.Color(255, 255, 255));
        BtnBayar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasir/img/money.png"))); // NOI18N
        BtnBayar.setText("Pay Request");
        BtnBayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBayarActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Futura Hv BT", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 0, 51));
        jLabel13.setText("Cart");

        Time.setBackground(new java.awt.Color(255, 255, 255));
        Time.setFont(new java.awt.Font("Futura-Bold", 1, 12)); // NOI18N
        Time.setForeground(new java.awt.Color(153, 153, 153));
        Time.setCaretColor(new java.awt.Color(255, 255, 255));
        Time.setDisabledTextColor(new java.awt.Color(153, 0, 51));
        Time.setEnabled(false);
        Time.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TimeActionPerformed(evt);
            }
        });

        Date.setBackground(new java.awt.Color(255, 255, 255));
        Date.setFont(new java.awt.Font("Futura-Bold", 1, 12)); // NOI18N
        Date.setForeground(new java.awt.Color(153, 153, 153));
        Date.setCaretColor(new java.awt.Color(255, 255, 255));
        Date.setDisabledTextColor(new java.awt.Color(153, 0, 51));
        Date.setEnabled(false);
        Date.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        Date.setSelectionColor(new java.awt.Color(153, 0, 51));
        Date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DateActionPerformed(evt);
            }
        });

        refresh.setText("Refresh");
        refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Futura Hv BT", 0, 8)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 0, 51));
        jLabel9.setText("Please select product before you input Qty...");

        jLabel10.setFont(new java.awt.Font("Futura Hv BT", 0, 8)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 0, 51));
        jLabel10.setText("Please select product in cart before you click Delete...");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(InputProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(BtnSearch))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(InputQty, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(InputDiscount, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(BtnAdd))
                                    .addComponent(jLabel4)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(refresh)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(BtnDelete))
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel13)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(InputCash, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(jLabel6)
                                .addGap(10, 10, 10)
                                .addComponent(UangKembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 302, Short.MAX_VALUE)
                                .addComponent(jLabel10)
                                .addGap(32, 32, 32)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(Time, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Date, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(45, 45, 45))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(TotalHarga)
                                        .addComponent(BtnBayar)))
                                .addGap(37, 37, 37)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(KodeTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(81, 81, 81))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Date, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Time, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(InputProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnSearch))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(InputQty, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(InputDiscount, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(BtnAdd)))
                                .addGap(29, 29, 29)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(TotalHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(BtnDelete)
                            .addComponent(refresh))
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(InputCash, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(UangKembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BtnBayar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(KodeTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSearchActionPerformed
        cari();
    }//GEN-LAST:event_BtnSearchActionPerformed

    private void TabelInputProductNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelInputProductNameMouseClicked
        // TODO add your handling code here:
        try {
            int row=TabelInputProductName.getSelectedRow();
            String tabel_klik=(TabelInputProductName.getModel().getValueAt(row, 0).toString());
            String sql="select * from barang where Kode_Barang='"+tabel_klik+"'";
            pst=koneksi.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rst=pst.executeQuery();
            if (rst.next()) {
                barang=rst.getString(("Kode_Barang"));    
                String stok=rst.getString(("Stok"));
                istok= Integer.parseInt(stok);
                harga=rst.getString(("Harga"));
                iharga= Integer.parseInt(harga);
            }
        }catch (Exception e) {JOptionPane.showMessageDialog(null, e);}
    }//GEN-LAST:event_TabelInputProductNameMouseClicked

    private void BtnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAddActionPerformed
        if (InputQty.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Isi Qty!");
        } else {
            subtotal();
            kurangi_stok();
        }
    }//GEN-LAST:event_BtnAddActionPerformed

    private void InputQtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputQtyActionPerformed
        // TODO add your handling code here:
           
    }//GEN-LAST:event_InputQtyActionPerformed

    private void InputQtyPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_InputQtyPropertyChange
      
    }//GEN-LAST:event_InputQtyPropertyChange

    private void BtnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnDeleteActionPerformed
        int old = 0;
        String query = "DELETE FROM detail_barang WHERE id = ?";
        String query2 = "SELECT Stok FROM barang WHERE Kode_Barang = ?";
        
        try {
            pstmt = koneksi.prepareStatement(query2);
            pstmt.setString(1, selectedKB);
            rs = pstmt.executeQuery();
            rs.next();
            old = rs.getInt(1);
            pstmt.close();
            rs.close();
            
            String query3 = "UPDATE barang SET Stok='" + (old+selectedJumlah) +"' where Kode_Barang='" + selectedKB + "'";
            
            pstmt2 = koneksi.prepareStatement(query3);
            pstmt2.execute();
            pstmt2.close();
            
            pstmt3 = koneksi.prepareStatement(query);
            pstmt3.setString(1, selectedId);
            pstmt3.execute();           
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "[ERROR] hapusKeranjangActionPerformed");
            JOptionPane.showMessageDialog(null, e);
        }
        
        cari();
        detail();
        sum();
    }//GEN-LAST:event_BtnDeleteActionPerformed

    private void TabelKeranjangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelKeranjangMouseClicked
        int row = TabelKeranjang.getSelectedRow();
        selectedId = (TabelKeranjang.getModel().getValueAt(row, 0).toString());
        selectedKB = (TabelKeranjang.getModel().getValueAt(row, 2).toString());
        selectedJumlah = (Integer.parseInt(TabelKeranjang.getModel().getValueAt(row, 4).toString()));
    }//GEN-LAST:event_TabelKeranjangMouseClicked

    private void BtnBayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBayarActionPerformed

        if (InputCash.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Please Input Your Cash Before Pay Request!!");
        } else if(Integer.parseInt(InputCash.getText().toString()) < Integer.parseInt(TotalHarga.getText().toString())) {
            JOptionPane.showMessageDialog(null, "Your Cash is Less!!");
        } else {
            total();
            simpan();
            autonumber();
            detail();
            TotalHarga.setText("");
            InputCash.setText("");
            UangKembalian.setText("");
            InputProductName.setText("");
            cari();   
        }      
    }//GEN-LAST:event_BtnBayarActionPerformed

    private void LabelCashierMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LabelCashierMouseClicked
        
    }//GEN-LAST:event_LabelCashierMouseClicked

    private void LabelReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LabelReportMouseClicked
        new subpopup().setVisible(true);
        dispose();
    }//GEN-LAST:event_LabelReportMouseClicked

    private void LabelProductDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LabelProductDataMouseClicked
        new Barang().setVisible(true);
        dispose();
    }//GEN-LAST:event_LabelProductDataMouseClicked

    private void UangKembalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UangKembalianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UangKembalianActionPerformed

    private void LabelLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LabelLogoutMouseClicked
        // TODO add your handling code here:
        new login().setVisible(true);
        dispose();
    }//GEN-LAST:event_LabelLogoutMouseClicked

    private void DateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DateActionPerformed

    private void InputDiscountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputDiscountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_InputDiscountActionPerformed

    private void InputQtyKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_InputQtyKeyTyped
        // TODO add your handling code here:
        char iNumber = evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_InputQtyKeyTyped

    private void InputDiscountKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_InputDiscountKeyTyped
        // TODO add your handling code here:
        char iNumber = evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_InputDiscountKeyTyped

    private void InputCashKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_InputCashKeyTyped
        // TODO add your handling code here:
        char iNumber = evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_InputCashKeyTyped

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        detail();
        sum();
    }//GEN-LAST:event_refreshActionPerformed

    private void InputCashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputCashActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_InputCashActionPerformed

    private void TotalHargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalHargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TotalHargaActionPerformed

    private void LabelKaryawanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LabelKaryawanMouseClicked
        // TODO add your handling code here:
        new Karyawan().setVisible(true);
        dispose();
    }//GEN-LAST:event_LabelKaryawanMouseClicked

    private void TimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TimeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAdd;
    private javax.swing.JButton BtnBayar;
    private javax.swing.JButton BtnDelete;
    private javax.swing.JToggleButton BtnSearch;
    private javax.swing.JTextField Date;
    private javax.swing.JTextField InputCash;
    private javax.swing.JTextField InputDiscount;
    private javax.swing.JTextField InputProductName;
    private javax.swing.JTextField InputQty;
    private javax.swing.JTextField KodeTransaksi;
    private javax.swing.JLabel LabelCashier;
    private javax.swing.JLabel LabelKaryawan;
    private javax.swing.JLabel LabelLogout;
    private javax.swing.JLabel LabelProductData;
    private javax.swing.JLabel LabelReport;
    private javax.swing.JTable TabelInputProductName;
    private javax.swing.JTable TabelKeranjang;
    private javax.swing.JTextField Time;
    private javax.swing.JTextField TotalHarga;
    private javax.swing.JTextField UangKembalian;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton refresh;
    // End of variables declaration//GEN-END:variables
}
